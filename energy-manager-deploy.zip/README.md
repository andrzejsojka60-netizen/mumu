# 精力管理系统 — Energy Manager

基于《超级清单：精力管理实用技巧、表格与自我训练》的 PWA 应用。

## 功能

- 📋 **每日计划** — 设定每日重点事项，勾选完成
- 📝 **精力记录** — 按时间段记录精力评分、分类（工作/休息/其它）
- 🧰 **恢复工具箱 & 习惯打卡** — 内置恢复方法，打卡追踪
- 📊 **数据分析** — 精力趋势图、各时段统计

## 部署到 GitHub Pages

1. 在 GitHub 创建新仓库（如 `energy-manager`）
2. 将此文件夹内所有文件上传到仓库根目录
3. Settings → Pages → Source 选 `main` 分支，根目录 `/`，Save
4. 等待1-2分钟，访问 `https://你的用户名.github.io/energy-manager/`

## 离线使用

本应用是 PWA，支持：
- 浏览器打开后点击地址栏安装图标添加到桌面
- Service Worker 离线缓存，无网络也能使用
- 数据存储在浏览器 localStorage 中
